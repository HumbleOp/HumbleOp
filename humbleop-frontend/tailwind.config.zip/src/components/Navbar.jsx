// src/components/Navbar.jsx
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useEffect, useState } from "react";

export default function Navbar() {
  const { token, logout } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");

  useEffect(() => {
    async function fetchProfile() {
      if (!token) return;
      const res = await fetch("http://localhost:5000/profile", {
        headers: { Authorization: "Bearer " + token },
      });
      const data = await res.json();
      if (res.ok && data.username) setUsername(data.username);
    }
    fetchProfile();
  }, [token]);

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white shadow border-b sticky top-0 z-50">
      <div className="flex gap-4 items-center">
        <NavLink to="/posts" className="font-bold text-lg text-blue-700">
          HumbleOp
        </NavLink>
        <NavLink
          to="/posts"
          className={({ isActive }) =>
            isActive ? "text-blue-900 underline" : "text-blue-700 hover:underline"
          }
        >
          All Posts
        </NavLink>
        <NavLink
          to="/completed"
          className={({ isActive }) =>
            isActive ? "text-blue-900 underline" : "text-blue-700 hover:underline"
          }
        >
          Completed
        </NavLink>
        {token && (
          <>
            <NavLink
              to="/create"
              className={({ isActive }) =>
                isActive ? "text-blue-900 underline" : "text-blue-700 hover:underline"
              }
            >
              New Post
            </NavLink>
            <NavLink
              to="/profile"
              className={({ isActive }) =>
                isActive ? "text-blue-900 underline" : "text-blue-700 hover:underline"
              }
            >
              Profile
            </NavLink>
          </>
        )}
      </div>

      {token && (
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-700">{username}</span>
          <button
            onClick={() => {
              logout();
              navigate("/");
            }}
            className="text-sm text-red-600 hover:underline"
          >
            Logout
          </button>
        </div>
      )}
    </div>
  );
}
